import React, {Component} from 'react';
import { Router, Route, hashHistory } from 'react-router';
import { Provider } from 'react-redux';
import {store} from "../store";

import AppCpt from "../containers/App";
import LoginCpt from "../containers/login.jsx";
import MainFrameCpt from "../containers/MainFrame";
import {InstantMessagCpt} from "../containers/instantMessag";

export default class Root extends Component{
	render(){
		return (
			<Provider store={store}>
				<Router history={hashHistory}>
					<Route path="/" name="12" component={AppCpt}>
						<Route path="/login" component={LoginCpt}/>
						
						<Route path="/main" component={MainFrameCpt}>
    						<Route path="/im" component={InstantMessagCpt} />
    					</Route>
					</Route>
  				</Router>
			</Provider>
		);
	}
}
// 	