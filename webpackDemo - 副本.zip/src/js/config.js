let config = {
	server: {
		SERVER_IP: '192.168.0.104',
		SERVER_PROT: 8080
	},
	user: {
		username: 'huangping01',
		psd: 'qazw+123'
	}
}
module.exports = config;