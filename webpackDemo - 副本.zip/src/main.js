import React from 'react';
import {render} from "react-dom";
import Root from "./router/Root";

render(
	<Root />,
	document.querySelector(".root")
);

// import { createStore, applyMiddleware, combineReducers } from 'redux';
// Reducer createStore  store.getState store.dispatch store.subscribe


/*
Object.assign
Store
维持应用的 state；
提供 getState() 方法获取 state；
提供 dispatch(action) 方法更新 state；
通过 subscribe(listener) 注册监听器;
通过 subscribe(listener) 返回的函数注销监听器。
*/