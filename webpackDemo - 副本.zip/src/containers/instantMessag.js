import React, {Component} from 'react';
import { connect } from 'react-redux';
// import {DatePicker} from 'antd';
// console.log(connect);
class InstantMessagCpt1 extends Component{
	render(){
		console.log(this.props);
		return <div onClick={this.props.onClick}>InstantMessag23</div>;
	}
}
function mapStateToProps(state, ownProps){
	// console.error('mapStateToProps');
	// console.log(ownProps);
	// console.log(state);
	return {
		state
	}
}
function mapDispatchToProps(dispatch, ownProps){
	// console.error('mapDispatchToProps');
	// console.log(ownProps);
	return {
		onClick: ()=>{
			dispatch({type: 'LOGIN'});
			console.log(123);
		}
	}
}

let InstantMessagCpt = connect(mapStateToProps, mapDispatchToProps)(InstantMessagCpt1);
export {InstantMessagCpt}