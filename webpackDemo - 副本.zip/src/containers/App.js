import React, {Component} from 'react';
import DevTools from "../containers/DevTool";

let Tool = [
	<DevTools key="0"/>
];

export default class AppCpt extends Component{
	render(){
		// console.log(this.props);
		return (
			<div>
				{this.props.children}
				{Tool}
			</div>
		)
	}
}
document.addEventListener('contextmenu', function(e){
	console.log(111);
	e.returnValue = false;
	return false;
});
// 