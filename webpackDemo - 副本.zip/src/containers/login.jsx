import React, {Component} from 'react';
import { connect } from 'react-redux';
import config, {server, user} from "../js/config";
console.log(server);
console.log(user);

class LoginCpt extends Component{
	render(){
		let user = this.props.user;
		console.log(this.props);
		return (
			<div className="login-bg">
				<p><input id="user" defaultValue={user.username||''}/></p>
				<p><input type="password" id="psd" defaultValue={user.psd||''}/></p>
				<p><button>登录</button></p>
				<span className="ion-ios-gear"></span>
			</div>
		)
	}
}

function mapStateToProps(state, ownProps){
	return {
		user
	}
}
function mapDispatchToProps(dispatch, ownProps){
	return {
		onClick: ()=>{
			dispatch({type: 'LOGIN'});
			console.log(123);
		}
	}
}

export default connect(mapStateToProps, mapDispatchToProps)(LoginCpt);