import React, {Component} from "react";

export default class MainFrameCpt extends Component{
	render(){
		// console.log(this.props);
		return (
			<div>
				<div>
					nan
				</div>
				{this.props.children}
			</div>
		)
	}
}