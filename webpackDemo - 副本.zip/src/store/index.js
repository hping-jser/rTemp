import { createStore, applyMiddleware, combineReducers,compose } from 'redux';
import DevTools from "../containers/DevTool";
function actionFun(num){
	let type = num >=0 ? 'INCREMENT' : 'DECREMENT';
	return {
		type: type,
		num: Math.abs(num)
	}
}
function login(state = {}, action){
	console.error('isLogin');
	switch(action.type){
		case 'LOGIN':
			return Object.assign({}, state, {
				isLogin: !state.isLogin
			});
		default:
			return state;
	}
}
function calling(state = {callList:[]}, action){
	console.error('calling');
	switch(action.type){
		case 'CALLING':
			return Object.assign({}, state, {
				isLogin: !state.isLogin
			});
		default:
			return state;
	}
}
function counter(state = {count: 0}, action) {
	console.error('counter');
  switch (action.type) {
  case 'INCREMENT':
    return Object.assign({}, state, {
    	count: state.count + action.num || 0
    });
  case 'DECREMENT':
    return Object.assign({}, state, {
    	count: state.count - action.num || 0
    });
  default:
    return state;
  }
}

let reducer  = combineReducers({login, counter, calling});

const enhancer = compose(
  DevTools.instrument()
);
let store = createStore(reducer, enhancer);

// store.subscribe(() =>
//   console.log(store.getState())
// );
// store.dispatch({type: 'LOGIN'});
// store.dispatch({a:1});

// setTimeout(function() {
// 	store.dispatch(actionFun(2));
	// setTimeout(function() {
	// 	store.dispatch(actionFun(-1));
	// }, 5000);
// }, 1000);

// store.dispatch(actionFun(-1));
// store.dispatch({type: 'LOGIN'});
// store.dispatch(actionFun(0));


export {store};