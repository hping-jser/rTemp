let entrySrv = './src/main.js';
// let entrySrv = './Reddit/index.js';
module.exports = {
  entry: ['webpack/hot/dev-server', entrySrv],
  // entry: ['./src/main.js'],
  output: {
    path: './build',
    filename: 'bundle.js'
  },
  resolve: {
    extensions: ['', '.js', '.jsx']
  },
  module: {
    loaders: [
    {
      test: /\.(js|jsx)$/,
      loader: 'babel',
      exclude: /node_modules/,
      query: {
      	presets: ['react', 'es2015']
      }
  	}]
  }
};